run p2/p2_a.m
run p2/p2_b.m
run p3/p3.m