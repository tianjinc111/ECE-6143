run p4/p4.m
run p5/p5.m